"""
health app views -- patient-facing vitals, medications, lifestyle,
mental health, sharing, and the caregiver's read-only view.

Vitals and Medications are wired to real models. Dashboard, lifestyle,
mental health, sharing and the caregiver view are still demo data --
next build step.
"""
import datetime

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.shortcuts import redirect, render

from health.models import Medication, VitalRecord


def _refill_label(medication):
    if not medication.next_refill_date:
        return 'Not set'
    days_left = (medication.next_refill_date - datetime.date.today()).days
    if days_left < 0:
        return 'Overdue'
    if days_left == 0:
        return 'Today'
    return f"{days_left} days"


@login_required
def dashboard(request):
    context = {
        'vitals_summary': [
            {'label': 'Blood pressure', 'value': '128/82 mmHg', 'status': 'watch'},
            {'label': 'Blood sugar (fasting)', 'value': '96 mg/dL', 'status': 'normal'},
            {'label': 'Weight', 'value': '71.4 kg', 'status': 'normal'},
            {'label': 'Resting heart rate', 'value': '104 bpm', 'status': 'high'},
        ],
        'medication_reminders': [
            {'name': 'Metformin 500mg', 'time': '8:00 AM', 'taken': True},
            {'name': 'Amlodipine 5mg', 'time': '9:00 PM', 'taken': False},
        ],
        'upcoming_appointments': [
            {'provider': 'Dr. Anjali Nair', 'specialty': 'General Physician', 'when': 'Fri, 4 Jul - 10:30 AM'},
        ],
        'recommendation': "Your last two blood-pressure readings trended high -- consider a low-sodium diet and "
                           "recheck in 3 days. This suggestion is informational, not a diagnosis.",
        'alerts': [
            {'level': 'warning', 'text': 'Resting heart rate has been above 100 bpm for 2 consecutive readings.'},
        ],
    }
    return render(request, 'health/dashboard.html', context)


@login_required
def vitals(request):
    if request.method == 'POST':
        bp_systolic = bp_diastolic = blood_sugar = weight_kg = heart_rate = None
        try:
            bp_raw = request.POST.get('bp', '')
            systolic_raw, sep, diastolic_raw = bp_raw.partition('/')
            if not sep:
                raise ValueError('Enter blood pressure as systolic/diastolic, e.g. 120/80.')
            bp_systolic = int(systolic_raw.strip())
            bp_diastolic = int(diastolic_raw.strip())
            blood_sugar_raw = request.POST.get('blood_sugar', '')
            weight_raw = request.POST.get('weight_kg', '')
            heart_rate_raw = request.POST.get('heart_rate', '')
            blood_sugar = float(blood_sugar_raw) if blood_sugar_raw else None
            weight_kg = float(weight_raw) if weight_raw else None
            heart_rate = int(heart_rate_raw) if heart_rate_raw else None
        except ValueError as exc:
            messages.error(request, str(exc) if str(exc) else 'Please check the values you entered.')
        else:
            VitalRecord.objects.create(
                patient=request.user,
                bp_systolic=bp_systolic,
                bp_diastolic=bp_diastolic,
                blood_sugar=blood_sugar,
                weight_kg=weight_kg,
                heart_rate=heart_rate,
            )
            messages.success(request, 'Vitals saved.')
        return redirect('health_vitals')

    records = request.user.vital_records.all()[:20]
    entries = [
        {
            'date': r.recorded_at.strftime('%d %b %Y'),
            'bp': f"{r.bp_systolic}/{r.bp_diastolic}",
            'sugar': r.blood_sugar if r.blood_sugar is not None else '--',
            'weight': r.weight_kg if r.weight_kg is not None else '--',
            'hr': r.heart_rate if r.heart_rate is not None else '--',
            'status': r.status.lower(),
        }
        for r in records
    ]
    return render(request, 'health/vitals.html', {'entries': entries})


@login_required
def medications(request):
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        dose = request.POST.get('dose', '').strip()
        schedule = request.POST.get('schedule', '').strip()
        start_date = request.POST.get('start_date', '').strip()
        if not (name and dose and schedule and start_date):
            messages.error(request, 'Please fill in the medicine name, dose, schedule and start date.')
        else:
            try:
                Medication.objects.create(
                    patient=request.user, name=name, dose=dose, schedule=schedule, start_date=start_date,
                )
            except ValidationError:
                messages.error(request, 'Please enter a valid start date.')
            else:
                messages.success(request, 'Medicine added.')
        return redirect('health_medications')

    active = [
        {'name': m.name, 'dose': m.dose, 'schedule': m.schedule, 'refill_in': _refill_label(m)}
        for m in request.user.medications.filter(active=True)
    ]
    context = {
        'active': active,
        'extraction_demo': {
            'raw_text': "Tab. Metform 500mg 1-0-1 x 30 days\nTab. Amlogard 5mg 0-0-1 x 30 days",
            'extracted': [
                {'medicine': 'Metformin', 'dose': '500 mg', 'duration': '30 days', 'confidence': 'High'},
                {'medicine': 'Amlodipine', 'dose': '5 mg', 'duration': '30 days', 'confidence': 'Medium'},
            ],
        },
        'interaction_warning': {
            'drug_a': 'Amlodipine',
            'drug_b': 'Simvastatin',
            'note': 'Concurrent use may increase simvastatin levels -- flagged from db_drug_interactions.csv.',
        },
    }
    return render(request, 'health/medications.html', context)


@login_required
def lifestyle(request):
    context = {
        'entries': [
            {'date': '01 Jul 2026', 'sleep': '6.5 hrs', 'water': '1.8 L', 'activity': '20 min walk'},
            {'date': '30 Jun 2026', 'sleep': '7.2 hrs', 'water': '2.1 L', 'activity': '35 min walk'},
            {'date': '29 Jun 2026', 'sleep': '5.8 hrs', 'water': '1.4 L', 'activity': 'Rest day'},
        ],
    }
    return render(request, 'health/lifestyle.html', context)


@login_required
def mental_health(request):
    context = {
        'entries': [
            {'date': '01 Jul 2026', 'mood': 'Calm', 'note': 'Slept well, felt steady through the day.'},
            {'date': '29 Jun 2026', 'mood': 'Stressed', 'note': 'Work deadline, trouble winding down at night.'},
            {'date': '27 Jun 2026', 'mood': 'Good', 'note': 'Long walk with a friend, mood lifted.'},
        ],
    }
    return render(request, 'health/mental_health.html', context)


@login_required
def share_records(request):
    context = {
        'active_shares': [
            {'with': 'Dr. Anjali Nair', 'scope': 'Vitals + Medications', 'expires': 'in 2 hours', 'code': 'SHC-7F2K9'},
        ],
        'history': [
            {'with': 'Caregiver -- Priya T', 'scope': 'Vitals only', 'action': 'Revoked', 'when': '18 Jun 2026'},
        ],
    }
    return render(request, 'health/share_records.html', context)


@login_required
def caregiver_dashboard(request):
    context = {
        'patient_name': 'Sreenanda T',
        'linked_since': '12 Jun 2026',
        'vitals_summary': [
            {'label': 'Blood pressure', 'value': '128/82 mmHg', 'status': 'watch'},
            {'label': 'Weight', 'value': '71.4 kg', 'status': 'normal'},
            {'label': 'Resting heart rate', 'value': '104 bpm', 'status': 'high'},
        ],
        'critical_alerts': [
            {'text': 'Missed evening Amlodipine dose on 30 Jun 2026.'},
        ],
        'weekly_summary': "Vitals were mostly stable this week with one high heart-rate reading and one missed "
                           "medication dose. No critical trends detected.",
    }
    return render(request, 'health/caregiver_dashboard.html', context)
