"""
health app models -- the patient's health data (physical + mental).
"""
from django.conf import settings
from django.db import models


class VitalRecord(models.Model):
    class Status(models.TextChoices):
        NORMAL = 'NORMAL', 'Normal'
        WATCH = 'WATCH', 'Watch'
        HIGH = 'HIGH', 'High'

    patient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='vital_records')
    recorded_at = models.DateTimeField(auto_now_add=True)
    bp_systolic = models.PositiveIntegerField()
    bp_diastolic = models.PositiveIntegerField()
    blood_sugar = models.DecimalField(max_digits=6, decimal_places=1, null=True, blank=True)
    weight_kg = models.DecimalField(max_digits=5, decimal_places=1, null=True, blank=True)
    heart_rate = models.PositiveIntegerField(null=True, blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.NORMAL)

    class Meta:
        ordering = ['-recorded_at']

    def compute_status(self):
        # Simple, explainable rule-based thresholds -- a stand-in for the
        # ML-based anomaly detection planned in tasks 3.4/4.4.
        if self.bp_systolic >= 140 or self.bp_diastolic >= 90 or (self.heart_rate and self.heart_rate >= 110):
            return self.Status.HIGH
        if self.bp_systolic >= 130 or self.bp_diastolic >= 85 or (self.heart_rate and self.heart_rate >= 100):
            return self.Status.WATCH
        return self.Status.NORMAL

    def save(self, *args, **kwargs):
        self.status = self.compute_status()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.patient} -- {self.recorded_at:%d %b %Y}"


class Medication(models.Model):
    patient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='medications')
    name = models.CharField(max_length=120)
    dose = models.CharField(max_length=60)
    schedule = models.CharField(max_length=120)
    start_date = models.DateField()
    next_refill_date = models.DateField(null=True, blank=True)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ['-start_date']

    def __str__(self):
        return f"{self.name} ({self.patient})"


class LifestyleLog(models.Model):
    patient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='lifestyle_logs')
    date = models.DateField()
    sleep_hours = models.DecimalField(max_digits=3, decimal_places=1, null=True, blank=True)
    water_litres = models.DecimalField(max_digits=3, decimal_places=1, null=True, blank=True)
    activity_note = models.CharField(max_length=200, blank=True)

    class Meta:
        unique_together = [('patient', 'date')]
        ordering = ['-date']

    def __str__(self):
        return f"{self.patient} -- {self.date}"


class MoodLog(models.Model):
    """
    Mental health check-ins. Per CONSENT_FRAMEWORK_DESIGN.md this data must
    never be shared with providers/caregivers without explicit, separate
    consent -- it is excluded from the general health-sharing scope by design.
    """
    patient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='mood_logs')
    date = models.DateField()
    mood = models.CharField(max_length=40)
    note = models.TextField(blank=True)

    class Meta:
        ordering = ['-date']

    def __str__(self):
        return f"{self.patient} -- {self.date} ({self.mood})"
