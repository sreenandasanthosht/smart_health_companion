"""
accounts app views -- registration, login, logout and onboarding.

Registration creates a real User row (and a CaregiverLink or
ProviderProfile row where relevant) and starts a real session.
"""
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError
from django.shortcuts import redirect, render

from accounts.forms import LoginForm, PUBLIC_ROLE_CHOICES, RegisterForm
from accounts.models import CaregiverLink, User

ONBOARDING_CONTENT = {
    'PATIENT': {
        'label': 'Patient',
        'heading': 'Tell us about your health baseline',
        'steps': [
            {
                'title': 'Demographics',
                'fields': ['Date of birth', 'Sex', 'Height', 'Blood group'],
            },
            {
                'title': 'Hereditary / existing conditions',
                'fields': ['Family history (diabetes, hypertension, heart disease...)', 'Existing diagnoses', 'Known allergies'],
            },
            {
                'title': 'Baseline vitals',
                'fields': ['Blood pressure', 'Blood sugar (fasting)', 'Weight', 'Resting heart rate'],
            },
        ],
        'next_url_name': 'health_dashboard',
        'next_label': 'Go to my dashboard',
    },
    'CAREGIVER': {
        'label': 'Caregiver',
        'heading': 'Link to the patient you support',
        'steps': [
            {
                'title': 'Your details',
                'fields': ['Relationship to patient (parent, child, spouse...)', 'Contact number'],
            },
            {
                'title': 'Link a patient',
                'fields': ["Patient's unique ID (shared by the patient)", 'Request sent -- patient must approve the link'],
            },
        ],
        'next_url_name': 'health_caregiver_dashboard',
        'next_label': 'Go to caregiver dashboard',
    },
    'PROVIDER': {
        'label': 'Provider',
        'heading': 'Submit your credentials for verification',
        'steps': [
            {
                'title': 'Professional details',
                'fields': ['Specialty', 'Years of experience', 'Clinic / hospital affiliation'],
            },
            {
                'title': 'Licence & qualifications',
                'fields': ['Medical licence number', 'Upload licence document', 'Upload qualification certificate'],
            },
            {
                'title': 'Awaiting admin approval',
                'fields': ['An administrator reviews every submission before your listing goes live'],
            },
        ],
        'next_url_name': 'provider_pending',
        'next_label': 'See verification status',
    },
}

ROLE_DASHBOARD_URL = {
    User.Role.PATIENT: 'health_dashboard',
    User.Role.CAREGIVER: 'health_caregiver_dashboard',
    User.Role.PROVIDER: 'provider_dashboard',
    User.Role.ADMIN: 'admin_dashboard',
    User.Role.NURSE: 'home',
}


def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            confirm_password = form.cleaned_data['confirm_password']
            role = form.cleaned_data['role']
            full_name = form.cleaned_data['full_name']
            phone_number = form.cleaned_data['phone_number']

            if password != confirm_password:
                form.add_error('confirm_password', "Passwords don't match.")
            elif User.objects.filter(username__iexact=email).exists():
                form.add_error('email', 'An account with this email already exists.')
            else:
                try:
                    validate_password(password)
                except ValidationError as exc:
                    for err in exc.messages:
                        form.add_error('password', err)

            if not form.errors:
                first_name, _, last_name = full_name.partition(' ')
                user = User.objects.create_user(
                    username=email,
                    email=email,
                    password=password,
                    first_name=first_name,
                    last_name=last_name,
                    role=role,
                    phone_number=phone_number,
                )

                if role == User.Role.CAREGIVER:
                    patient_id = form.cleaned_data['caregiver_patient_id'].strip().upper()
                    patient = User.objects.filter(unique_id=patient_id, role=User.Role.PATIENT).first()
                    if patient:
                        CaregiverLink.objects.create(patient=patient, caregiver=user)
                    else:
                        messages.warning(
                            request,
                            "We couldn't find a patient with that unique ID -- you can link a patient later."
                        )

                if role == User.Role.PROVIDER:
                    from providers.models import ProviderProfile
                    ProviderProfile.objects.create(
                        user=user,
                        provider_type=form.cleaned_data['provider_type'],
                    )

                login(request, user)
                messages.success(request, f"Welcome, {first_name or full_name}! Your account has been created.")
                return redirect('onboarding', role=role.lower())
    else:
        form = RegisterForm()
    return render(request, 'accounts/register.html', {'form': form, 'roles': PUBLIC_ROLE_CHOICES})


def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            user = authenticate(request, username=email, password=password)
            if user is not None:
                login(request, user)
                return redirect(ROLE_DASHBOARD_URL.get(user.role, 'home'))
            form.add_error(None, 'Incorrect email or password.')
    else:
        form = LoginForm()
    return render(request, 'accounts/login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('home')


@login_required
def onboarding_view(request, role):
    role_key = role.upper()
    content = ONBOARDING_CONTENT.get(role_key, ONBOARDING_CONTENT['PATIENT'])
    if request.method == 'POST':
        return redirect(content['next_url_name'])
    return render(request, 'accounts/onboarding.html', {'content': content, 'role': role_key})
