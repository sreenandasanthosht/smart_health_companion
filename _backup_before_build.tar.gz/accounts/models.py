"""
accounts app -- everything about USERS.
We define ONE custom user that covers all user types via a `role` field,
and give every user a short unique_id (used for caregiver linking and for
patients finding providers).
"""
import uuid
from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    class Role(models.TextChoices):
        PATIENT = 'PATIENT', 'Patient'
        CAREGIVER = 'CAREGIVER', 'Caregiver'
        PROVIDER = 'PROVIDER', 'Provider'
        ADMIN = 'ADMIN', 'Admin'
        NURSE = 'NURSE', 'Nurse'

    role = models.CharField(
        max_length=20, choices=Role.choices, default=Role.PATIENT
    )
    unique_id = models.CharField(max_length=12, unique=True, blank=True)
    # Collected at registration; used for reminders / contact. Optional so
    # it never blocks an existing account.
    phone_number = models.CharField(max_length=20, blank=True)

    def save(self, *args, **kwargs):
        # auto-generate a unique id the first time the user is saved
        if not self.unique_id:
            self.unique_id = uuid.uuid4().hex[:10].upper()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.username} ({self.get_role_display()})"


class CaregiverLink(models.Model):
    """
    Links a Caregiver account to the Patient they support. Created when a
    caregiver registers with a patient's unique ID; the patient approving
    the link (so the caregiver dashboard shows real data) is a follow-up
    build step -- for now a link is created as PENDING and can be flipped
    to APPROVED from /admin/.
    """
    class Status(models.TextChoices):
        PENDING = 'PENDING', 'Pending'
        APPROVED = 'APPROVED', 'Approved'
        REJECTED = 'REJECTED', 'Rejected'

    patient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='caregiver_links')
    caregiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name='patient_links')
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    requested_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [('patient', 'caregiver')]

    def __str__(self):
        return f"{self.caregiver} -> {self.patient} ({self.status})"
