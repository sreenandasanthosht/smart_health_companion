"""
providers app -- provider listings and appointments.
"""
from django.conf import settings
from django.db import models


class ProviderProfile(models.Model):
    class ProviderType(models.TextChoices):
        DOCTOR = 'DOCTOR', 'Doctor'
        CLINIC = 'CLINIC', 'Clinic'
        HOSPITAL = 'HOSPITAL', 'Hospital'
        DIAGNOSTIC_LAB = 'DIAGNOSTIC_LAB', 'Diagnostic Lab'
        PHARMACY = 'PHARMACY', 'Pharmacy'
        DIETICIAN = 'DIETICIAN', 'Dietician'
        FITNESS_CENTRE = 'FITNESS_CENTRE', 'Fitness Centre'
        WELLNESS_CENTRE = 'WELLNESS_CENTRE', 'Wellness Centre'

    class Verification(models.TextChoices):
        PENDING = 'PENDING', 'Pending Verification'
        VERIFIED = 'VERIFIED', 'Verified'
        NEEDS_INFO = 'NEEDS_INFO', 'Verification Required'

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='provider_profile')
    provider_type = models.CharField(max_length=20, choices=ProviderType.choices)
    specialty = models.CharField(max_length=120, blank=True)
    years_experience = models.PositiveIntegerField(null=True, blank=True)
    clinic_name = models.CharField(max_length=150, blank=True)
    address = models.CharField(max_length=255, blank=True)
    verification_status = models.CharField(max_length=12, choices=Verification.choices, default=Verification.PENDING)
    submitted_at = models.DateTimeField(auto_now_add=True)
    verified_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.user} ({self.get_provider_type_display()})"


class Appointment(models.Model):
    class Status(models.TextChoices):
        REQUESTED = 'REQUESTED', 'Requested'
        CONFIRMED = 'CONFIRMED', 'Confirmed'
        COMPLETED = 'COMPLETED', 'Completed'
        CANCELLED = 'CANCELLED', 'Cancelled'

    patient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='appointments_as_patient')
    provider = models.ForeignKey(ProviderProfile, on_delete=models.CASCADE, related_name='appointments')
    scheduled_for = models.DateTimeField()
    reason = models.CharField(max_length=200, blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.REQUESTED)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['scheduled_for']

    def __str__(self):
        return f"{self.patient} with {self.provider} on {self.scheduled_for:%d %b %Y}"
