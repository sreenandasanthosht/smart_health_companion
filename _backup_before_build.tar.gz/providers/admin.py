from django.contrib import admin

from providers.models import Appointment, ProviderProfile


@admin.register(ProviderProfile)
class ProviderProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'provider_type', 'verification_status', 'submitted_at')
    list_filter = ('provider_type', 'verification_status')
    search_fields = ('user__username', 'user__email', 'clinic_name')


@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('patient', 'provider', 'scheduled_for', 'status')
    list_filter = ('status',)
