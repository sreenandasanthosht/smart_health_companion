"""
providers app views -- the provider directory (marketplace), appointments,
the provider's own dashboard, and the pending-verification state.

`pending` is wired to the real ProviderProfile created at registration.
directory / appointments / dashboard are still demo data -- they need the
Appointment model to be populated by a real booking flow (next build step).
"""
from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from providers.models import ProviderProfile


@login_required
def directory(request):
    context = {
        'providers': [
            {'name': 'Dr. Anjali Nair', 'specialty': 'General Physician', 'experience': '9 yrs', 'verified': True},
            {'name': 'Dr. Rohan Mehta', 'specialty': 'Cardiologist', 'experience': '14 yrs', 'verified': True},
            {'name': 'Dr. Kavya Suresh', 'specialty': 'Endocrinologist', 'experience': '6 yrs', 'verified': True},
            {'name': 'Dr. Farhan Ali', 'specialty': 'Psychiatrist', 'experience': '11 yrs', 'verified': True},
            {'name': 'Dr. Meera Iyer', 'specialty': 'Dietitian', 'experience': '5 yrs', 'verified': True},
            {'name': 'Dr. Sanjay Kulkarni', 'specialty': 'Cardiologist', 'experience': '20 yrs', 'verified': True},
        ],
    }
    return render(request, 'providers/directory.html', context)


@login_required
def appointments(request):
    context = {
        'upcoming': [
            {'provider': 'Dr. Anjali Nair', 'specialty': 'General Physician', 'when': 'Fri, 4 Jul - 10:30 AM', 'status': 'Confirmed'},
        ],
        'past': [
            {'provider': 'Dr. Kavya Suresh', 'specialty': 'Endocrinologist', 'when': '15 Jun 2026', 'status': 'Completed'},
        ],
        'providers': [
            'Dr. Anjali Nair -- General Physician',
            'Dr. Rohan Mehta -- Cardiologist',
            'Dr. Kavya Suresh -- Endocrinologist',
            'Dr. Farhan Ali -- Psychiatrist',
        ],
    }
    return render(request, 'providers/appointments.html', context)


@login_required
def dashboard(request):
    context = {
        'provider_name': 'Dr. Anjali Nair',
        'requests': [
            {'patient': 'Sreenanda T', 'requested_for': 'Mon, 7 Jul - 9:00 AM', 'reason': 'Follow-up on blood pressure'},
        ],
        'upcoming': [
            {'patient': 'Terese M', 'when': 'Fri, 4 Jul - 10:30 AM', 'reason': 'General check-up'},
        ],
    }
    return render(request, 'providers/dashboard.html', context)


@login_required
def pending(request):
    profile = ProviderProfile.objects.filter(user=request.user).first()
    if profile:
        context = {
            'submitted_on': profile.submitted_at.strftime('%d %b %Y'),
            'documents': ['Registration certificate', 'Government ID', 'Clinic / organisation info', 'Address proof'],
            'verification_status': profile.get_verification_status_display(),
        }
    else:
        context = {
            'submitted_on': '--',
            'documents': [],
            'verification_status': 'Not submitted',
        }
    return render(request, 'providers/pending.html', context)
